CREATE DATABASE vsftpd DEFAULT CHARACTER SET latin2 COLLATE latin2_hungarian_ci;
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, DROP ON vsftpd.* TO 'vsftpd'@'localhost' IDENTIFIED BY 'jelszo';
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, DROP ON vsftpd.* TO 'vsftpd'@'localhost.localdomain' IDENTIFIED BY 'jelszo';
FLUSH PRIVILEGES;

USE vsftpd;

CREATE TABLE IF NOT EXISTS `accounts` (
`id` int(11) NOT NULL,
  `username` varchar(30) COLLATE latin2_hungarian_ci NOT NULL,
  `pass` varchar(50) COLLATE latin2_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin2 COLLATE=latin2_hungarian_ci;

