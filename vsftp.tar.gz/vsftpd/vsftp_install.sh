echo "Mindenre [ENTER]"
apt-get install vsftpd libpam-mysql mysql-server mysql-client phpmyadmin libpam-ldap
